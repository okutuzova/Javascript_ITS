# Exercise: 02-new-js

## Author Details
- **Name:** Olga Kutuzova  
- **Email:** olga.kutuzova@edu-its.it  
- **Course:** Web Developer 24-26


## Exercise Requirements
Build your first Javascript project  
● Write your index.html file from scratch  
● Add a main.js file that writes your name to the console  
Create a folder named 02-new-js with your solution  

## Solution
I created an index.html file following a pattern from the previous exercise. I created a folder named "script" which contains a "main.js" file. This file prints the name of a student to the browser console through a built-in Javascript function __console.log__. 



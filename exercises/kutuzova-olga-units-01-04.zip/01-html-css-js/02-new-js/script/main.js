/**
 * @file: main.js
 * @author: Olga Kutuzova
 * Exercise 02-new-js
 * 
 * This script prints the name of a student to the console.
 */

console.log('Olga Kutuzova');

/**
 * @file: main.js
 * @author: Olga Kutuzova
 * Exercise 06-enhanced-word-guesser
 * 
 * A browser-based Hangman game where the player tries to guess
 * a hidden country name by entering one letter at a time. Incorrect
 * guesses reveal parts of a stick figure. The game ends in a win
 * when the word is fully revealed, or a loss when all parts are shown.
 */

/**
 * List of available country names to randomly choose from.
 * @type {string[]}
 */
const words = ["ANDORRA", "ARGENTINA", "AUSTRALIA", "AUSTRIA",
    "AFGHANISTAN", "ALBANIA", "ALGERIA", "ANGOLA", "ARMENIA", "AZERBAIJAN",
    "BAHRAIN", "BANGLADESH", "BELGIUM", "BOLIVIA", "BRAZIL", 
    "BULGARIA", 
    "BAHAMAS", "BARBADOS", "BELARUS", "BENIN", "BHUTAN", "BOSNIAHERZEGOVINA", "BOTSWANA", "BURKINA", "BURUNDI",
    "CANADA", 
    "CABOVERDE", "CAMBODIA", "CAMEROON", "CENTRALAFRICANREPUBLIC", "CHAD", "COMOROS", "CONGO", "COSTARICA", "COTEDIVOIRE", "CUBA",
    "CHILE", "CHINA", "COLOMBIA", "CROATIA", "CZECHIA", "DENMARK", "DOMINICA", "ECUADOR", 
    "DJIBOUTI", "DOMINICANREPUBLIC", "EASTTIMOR", "ELSALVADOR", "EQUATORIALGUINEA", "ERITREA", "ESWATINI",
    "EGYPT", "ESTONIA", "ETHIOPIA", "FINLAND", "FRANCE", "GEORGIA", "GERMANY", "GHANA", 
    "FIJI", "GABON", "GAMBIA", "GRENADA", "GUATEMALA", "GUINEA", "GUINEABISSAU", "GUYANA",
    "HAITI", "KAZAKHSTAN", "KIRIBATI", "KYRGYZSTAN", "LAOS", "LESOTHO", "LIBERIA", "LIBYA", "LUXEMBOURG",
    "GREECE", "HUNGARY", "HONDURAS", "ICELAND", "INDIA", "INDONESIA", "IRAN", "IRAQ", "IRELAND", 
    "ISRAEL", "ITALY", "JAMAICA", "JAPAN", "JORDAN", "KENYA", "KUWAIT", "LATVIA", "LEBANON", 
    "LITHUANIA", "MALAYSIA", "MEXICO", "MOROCCO", "NEPAL", "NETHERLANDS", "NIGERIA", 
    "NORWAY", "OMAN", "PAKISTAN", "PERU", "PHILIPPINES", "POLAND", "PORTUGAL", "QATAR", "ROMANIA", 
    "RUSSIA", "SANMARINO", "SAUDIARABIA", "SENEGAL", "SERBIA", "SINGAPORE", "SLOVAKIA", "SLOVENIA", 
    "SOUTHAFRICA", "SOUTHKOREA", "SPAIN", "SWEDEN", "SWITZERLAND", "THAILAND", "TURKEY", 
    "MADAGASCAR", "MALAWI", "MALDIVES", "MALI", "MALTA", "MAURITANIA", "MAURITIUS", "MICRONESIA", "MOLDOVA", "MONACO", "MONGOLIA", "MONTENEGRO", "MOZAMBIQUE", "MYANMAR",
    "NAMIBIA", "NAURU", "NICARAGUA", "NIGER", "NORTHMACEDONIA", "PALAU", "PALESTINE", "PANAMA", "PAPUANEWGUINEA", "PARAGUAY", 
    "RWANDA", "SAINTKITTS", "SAINTLUCIA", "SAINTVINCENT", "SAMOA", "SAOTOME", "SEYCHELLES", "SIERRALEONE", "SOLOMONISLANDS", "SOMALIA", "SUDAN", "SOUTHOSSETIA", "SURINAME", "SYRIA",
    "TAIWAN", "TAJIKISTAN", "TANZANIA", "TOGO", "TONGA", "TRINIDADTOBAGO", "TUNISIA", "TURKMENISTAN", "TUVALU",
    "UGANDA", "UZBEKISTAN", "VANUATU", "VATICAN", "YEMEN", "ZAMBIA",
    "UKRAINE", "UNITEDKINGDOM", "UNITEDSTATES", "URUGUAY", "VENEZUELA", "VIETNAM", "ZIMBABWE"]; 

// Currently chosen word
let selectedWord = "";
// Correctly guessed letters
let guessedLetters = [];
// Incorrect guesses
let wrongLetters = [];
// Number of incorrect attempts
let errors = 0;
// Players score (+1 if guessed a word)
// let score = 0;
let scores = { 1: 0, 2: 0 };
// Current player 2 - the ternary operator on resetGame will change it to 1 on page load
let currentPlayer = 2;

/** @type {HTMLElement} */
const wordDisplay = document.getElementById("word-display");
/** @type {HTMLInputElement} */
const inputLetter = document.getElementById("input-letter");
/** @type {HTMLElement} */
const message = document.getElementById("message");
/** @type {NodeListOf<HTMLElement>} */
const figureParts = document.querySelectorAll(".figure-part");
/** @type {HTMLElement} */
const scoreDisplay = document.getElementById("score");
/** @type {HTMLElement} */
const errorsDisplay = document.getElementById("errors-remaining");
/** @type {HTMLElement} */
const usedLettersDisplay = document.getElementById("used-letters");
/** @type {HTMLElement} */
const newGameButton = document.getElementById("restart-btn");
/** @type {HTMLElement} */
const currentPlayerDisplay = document.getElementById("current-player");
/** @type {HTMLElement} */
const score1Display = document.getElementById("score1");
/** @type {HTMLElement} */
const score2Display = document.getElementById("score2");


/**
 * Selects a random word from the list.
 * @returns {string} Random country name.
 */
function getRandomWord() {
    return words[Math.floor(Math.random() * words.length)];
  }

// Initialize game on page load
window.addEventListener("load", resetGame);

/**
 * Updates the word display with guessed letters and underscores.
 * Also updates the display of used (wrong) letters.
 */
function displayWord() {
    const display = selectedWord
      .split("")
      .map(letter => guessedLetters.includes(letter) ? letter : "_")
      .join(" ");
      wordDisplay.textContent = display;
      // Used Letters Display
      usedLettersDisplay.textContent = "Used Letters: " + wrongLetters.join(", ");
}

/**
 * Reveals parts of the stick figure for each wrong guess.
 * Also updates the "lives remaining" counter.
 */
function updateFigure() {
    figureParts.forEach((part, index) => {
      // If index is less than errors, show part, otherwise hide
      if (index < errors) {
        part.classList.add("visible");
        part.classList.remove("hidden");
      } else {
        part.classList.add("hidden");
        part.classList.remove("visible");
      }
    });
    // Add remaining errors
    const remainingErrors = figureParts.length - errors;
    errorsDisplay.textContent = "Lives remaining: " + remainingErrors;
}

/**
 * Checks whether the player has guessed all letters.
 * If yes, shows a win message and updates the score.
 */
function checkWin() {
    // Check if there are "_" in the wordDisplay
    if (!wordDisplay.innerHTML.includes("_")) {
      message.textContent = `🏆 Player ${currentPlayer} Wins!`;
      scores[currentPlayer]++;  // increment score
      updateScores();
      inputLetter.disabled = true;  // disable input
    }
}

/**
 * Checks whether the player has run out of guesses.
 * If yes, shows a game over message with the correct word.
 */
function checkLoss() {
    if (errors >= figureParts.length) {
      message.textContent = "❌😢 Game Over! The word was: " + selectedWord;
      inputLetter.disabled = true;
    }
}

/**
 * Resets the game state to start a new round.
 * Chooses a new word and resets guesses, figure, messages, and inputs.
 */
function resetGame() {
    selectedWord = getRandomWord();
    guessedLetters = [];
    wrongLetters = [];
    errors = 0;
    message.textContent = "";
    inputLetter.disabled = false;
    displayWord();
    updateFigure();
    inputLetter.value = "";
    inputLetter.focus();
    usedLettersDisplay.textContent = "Letters used: ";
    errorsDisplay.textContent = "Lives remaining: " + figureParts.length;

    currentPlayer = currentPlayer === 1 ? 2 : 1;
    currentPlayerDisplay.textContent = `Player ${currentPlayer}'s turn`;
}

function updateScores() {
    score1Display.textContent = `${scores[1]}`;
    score2Display.textContent = `${scores[2]}`; 
}

/**
 * Handles user input: validates the letter, checks guess,
 * and updates game state accordingly.
 */
inputLetter.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    const letter = inputLetter.value.toUpperCase();
    inputLetter.value = "";
    
    if (!/^[A-Z]$/.test(letter) || letter.length!== 1) {
        message.textContent = "Please enter a single letter.";
        return;
    }
    
    if (guessedLetters.includes(letter) || wrongLetters.includes(letter)) {
        message.textContent = "You've already guessed that letter.";
        return;
    }    
    
    if (selectedWord.includes(letter)) {
        guessedLetters.push(letter);
    } else {
        errors++; 
        wrongLetters.push(letter);
    }
    displayWord();
    updateFigure();
    checkWin();
    checkLoss();
    inputLetter.value = "";
    }
});

// Button listener to start a new game
newGameButton.addEventListener("click", resetGame);


export const flights = Array.from({ length: 25 }, (_, index) => {
  const id = index + 1;
  const flightNumber = `HM${id.toString().padStart(3, '0')}`;

  const fromDestinations = [
    "Diagon Alley", "King's Cross Station", "Ministry of Magic", "Hogwarts",
    "Godric's Hollow", "Beauxbatons", "Durmstrang", "Little Whinging",
    "Forbidden Forest", "Gringotts Bank", "Shell Cottage", "The Burrow",
    "Azkaban", "Ottery St. Catchpole", "Knockturn Alley", "Spinner's End",
    "Malfoy Manor", "Hogs Head Inn", "Leaky Cauldron", "Ravenclaw Tower",
    "Slytherin Dungeons", "The Shrieking Shack", "Grimmauld Place", "Nurmengard", "Ilvermorny"
  ];

  const airlines = [
    "Ministry Express", "Hogwarts Express Air", "Auror Air", "Hogwarts Owls",
    "Phoenix Flyers", "BroomAir", "DarkMark Airlines", "Privet Jet",
    "Centaur Charters", "Vault Airlines", "Seaside Skies", "Weasley Wings",
    "Dementor Air", "Ottery Owls", "Shadow Flights", "Severus Skyways",
    "Snake Air", "InnSky", "Leaky Flights", "House Airlines",
    "Serpent Skies", "Howler Jets", "Order Air", "Duel Air", "Thunderbird Flights"
  ];

  return {
    id,
    flightNumber,
    from: fromDestinations[index],
    time: `${12 + Math.floor(index / 4)}:${String((index % 4) * 15).padStart(2, '0')}`,
    date: "2025-09-13",
    gate: `${fromDestinations[index][0]}${index + 1}`, // исправлено i -> index
    airline: airlines[index],
    status: "SCHEDULED"
  };
});

/**
 * A list of possible flight statuses.
 * @type {Array<string>}
 */
export const statuses = ["ON_TIME", "DELAYED", "DEPARTING", "DEPARTED", "EN_ROUTE", "ARRIVED", "CANCELLED"];

/**
 * A list of possible flight statuses.
 * @type {Array<string>}
 */
export const statuses = ["ON_TIME", "DELAYED", "DEPARTING", "DEPARTED", "EN_ROUTE", "ARRIVED", "CANCELLED"];

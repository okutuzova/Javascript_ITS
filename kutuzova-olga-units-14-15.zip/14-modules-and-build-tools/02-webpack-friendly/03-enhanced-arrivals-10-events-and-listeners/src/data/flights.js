/**
 * A list of all flights.
 * @type {Array<{ id: number, flightNumber: string, from: string, 
* time: string, date: string, gate: string, airline: string}>}
*/
export const flights = [
   { id: 1, flightNumber: "HM001", from: "Diagon Alley", time: "12:45", date: "2025-04-13", gate: "9¾", airline: "Ministry Express"},
   { id: 2, flightNumber: "HM002", from: "King's Cross Station", time: "13:00", date: "2025-04-13", gate: "K1", airline: "Hogwarts Express Air"},
   { id: 3, flightNumber: "HM003", from: "Ministry of Magic", time: "13:20", date: "2025-04-13", gate: "M1", airline: "Auror Air"},
   { id: 4, flightNumber: "HM004", from: "Hogwarts", time: "13:35", date: "2025-04-13", gate: "H1", airline: "Hogwarts Owls"},
   { id: 5, flightNumber: "HM005", from: "Godric's Hollow", time: "13:50", date: "2025-04-13", gate: "G1", airline: "Phoenix Flyers"},
   { id: 6, flightNumber: "HM006", from: "Beauxbatons", time: "14:00", date: "2025-04-13", gate: "B1", airline: "BroomAir"},
   { id: 7, flightNumber: "HM007", from: "Durmstrang", time: "14:10", date: "2025-04-13", gate: "D1", airline: "DarkMark Airlines"},
   { id: 8, flightNumber: "HM008", from: "Little Whinging", time: "14:20", date: "2025-04-13", gate: "L2", airline: "Privet Jet"},
   { id: 9, flightNumber: "HM009", from: "Forbidden Forest", time: "14:30", date: "2025-04-13", gate: "F1", airline: "Centaur Charters"},
   { id: 10, flightNumber: "HM010", from: "Gringotts Bank", time: "14:45", date: "2025-04-13", gate: "G2", airline: "Vault Airlines"},
   { id: 11, flightNumber: "HM011", from: "Shell Cottage", time: "15:00", date: "2025-04-13", gate: "S1", airline: "Seaside Skies"},
   { id: 12, flightNumber: "HM012", from: "The Burrow", time: "15:15", date: "2025-04-13", gate: "B2", airline: "Weasley Wings"},
   { id: 13, flightNumber: "HM013", from: "Azkaban", time: "15:30", date: "2025-04-13", gate: "Z1", airline: "Dementor Air"},
   { id: 14, flightNumber: "HM014", from: "Ottery St. Catchpole", time: "15:45", date: "2025-04-13", gate: "O1", airline: "Ottery Owls"},
   { id: 15, flightNumber: "HM015", from: "Knockturn Alley", time: "16:00", date: "2025-04-13", gate: "N1", airline: "Shadow Flights"},
   { id: 16, flightNumber: "HM016", from: "Spinner's End", time: "16:10", date: "2025-04-13", gate: "S2", airline: "Severus Skyways"},
   { id: 17, flightNumber: "HM017", from: "Malfoy Manor", time: "16:25", date: "2025-04-13", gate: "M2", airline: "Snake Air"},
   { id: 18, flightNumber: "HM018", from: "Hogs Head Inn", time: "16:35", date: "2025-04-13", gate: "H2", airline: "InnSky"},
   { id: 19, flightNumber: "HM019", from: "Leaky Cauldron", time: "16:50", date: "2025-04-13", gate: "L3", airline: "Leaky Flights"},
   { id: 20, flightNumber: "HM020", from: "Ravenclaw Tower", time: "17:00", date: "2025-04-13", gate: "R1", airline: "House Airlines"},
   { id: 21, flightNumber: "HM021", from: "Slytherin Dungeons", time: "17:10", date: "2025-04-13", gate: "S3", airline: "Serpent Skies"},
   { id: 22, flightNumber: "HM022", from: "The Shrieking Shack", time: "17:20", date: "2025-04-13", gate: "T1", airline: "Howler Jets"},
   { id: 23, flightNumber: "HM023", from: "Grimmauld Place", time: "17:35", date: "2025-04-13", gate: "G3", airline: "Order Air"},
   { id: 24, flightNumber: "HM024", from: "Nurmengard", time: "17:50", date: "2025-04-13", gate: "N2", airline: "Duel Air"},
   { id: 25, flightNumber: "HM025", from: "Ilvermorny", time: "18:00", date: "2025-04-13", gate: "I1", airline: "Thunderbird Flights"}
 ];